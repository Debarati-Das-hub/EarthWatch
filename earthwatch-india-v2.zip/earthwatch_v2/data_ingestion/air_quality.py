"""
data_ingestion/air_quality.py
Real AQI data from OpenAQ (mirrors India CPCB stations).
"""
import requests
from datetime import datetime
from config import OPENAQ_KEY, ZONES


def get_aqi(zone):
    try:
        headers = {"X-API-Key": OPENAQ_KEY} if OPENAQ_KEY and OPENAQ_KEY != "your_openaq_key_here" else {}
        r = requests.get(
            "https://api.openaq.org/v3/locations",
            params={"coordinates": f"{zone['lat']},{zone['lon']}",
                    "radius": 30000, "limit": 5},
            headers=headers, timeout=10
        )
        r.raise_for_status()
        locs = r.json().get("results", [])
        if not locs:
            return None

        # Get latest measurements
        loc_id = locs[0]["id"]
        mr = requests.get(
            f"https://api.openaq.org/v3/locations/{loc_id}/latest",
            headers=headers, timeout=10
        )
        mr.raise_for_status()
        readings = {}
        for result in mr.json().get("results", []):
            for sensor in result.get("sensors", []):
                name = sensor.get("parameter", {}).get("name", "")
                val  = sensor.get("value")
                if name and val is not None:
                    readings[name] = round(float(val), 1)

        pm25 = readings.get("pm25") or readings.get("pm2.5")
        pm10 = readings.get("pm10")
        no2  = readings.get("no2")

        if pm25 is None:
            return None

        aqi  = pm25_to_aqi(pm25)
        cat  = aqi_category(aqi)

        return {
            "zone":     zone,
            "pm25":     pm25,
            "pm10":     pm10,
            "no2":      no2,
            "aqi":      aqi,
            "category": cat,
            "station":  locs[0].get("name", "CPCB Station"),
        }
    except Exception as e:
        print(f"    ⚠️  AQ error {zone['name']}: {e}")
        return None


def pm25_to_aqi(pm25):
    # India CPCB breakpoints
    bp = [(0,30,0,50),(30,60,51,100),(60,90,101,200),
          (90,120,201,300),(120,250,301,400),(250,500,401,500)]
    for cl, ch, il, ih in bp:
        if cl <= pm25 <= ch:
            return round(((ih-il)/(ch-cl))*(pm25-cl)+il)
    return 500


def aqi_category(aqi):
    if aqi <= 50:   return {"label": "Good",         "color": "#22c55e", "sev": 0}
    if aqi <= 100:  return {"label": "Satisfactory",  "color": "#84cc16", "sev": 2}
    if aqi <= 200:  return {"label": "Moderate",      "color": "#eab308", "sev": 4}
    if aqi <= 300:  return {"label": "Poor",          "color": "#f97316", "sev": 6}
    if aqi <= 400:  return {"label": "Very Poor",     "color": "#ef4444", "sev": 8}
    return           {"label": "Severe",              "color": "#7c3aed", "sev": 10}


def build_alerts(aq_data):
    alerts = []
    for d in aq_data:
        if not d or d["category"]["sev"] < 4:
            continue
        zone = d["zone"]
        aqi  = d["aqi"]
        cat  = d["category"]
        pm25 = d["pm25"]

        alerts.append({
            "type":       "air_quality",
            "title":      f"😷 {cat['label']} Air Quality — {zone['name']} (AQI {aqi})",
            "location":   zone["name"],
            "state":      zone["state"],
            "lat":        zone["lat"],
            "lon":        zone["lon"],
            "severity":   cat["sev"],
            "confidence": "HIGH",
            "source":     "OpenAQ / CPCB India",
            "aqi_color":  cat["color"],
            "details": {
                "AQI (India CPCB Scale)": f"{aqi} — {cat['label']}",
                "PM2.5":                  f"{pm25} µg/m³  (WHO safe: 15 µg/m³)",
                "PM10":                   f"{d['pm10']} µg/m³" if d["pm10"] else "N/A",
                "NO₂":                    f"{d['no2']} µg/m³" if d["no2"] else "N/A",
                "Monitoring Station":     d["station"],
                "Times Over WHO Limit":   f"{round(pm25/15, 1)}x",
                "Primary Source":         pollution_source(zone["name"]),
            },
            "damage": {
                "Health Risk":           health_risk(aqi),
                "Sensitive Groups":      sensitive(aqi),
                "Recommended Action":    action(aqi),
                "School Closure":        "RECOMMENDED" if aqi > 400 else "Not required",
                "Outdoor Activity":      "BANNED" if aqi > 400 else ("AVOID" if aqi > 300 else "LIMIT"),
                "ER Visits (Expected)":  er_visits(aqi),
            },
            "fetched_at": datetime.utcnow().isoformat()
        })
    return alerts


def pollution_source(city):
    sources = {
        "Delhi":     "Vehicles + stubble burning + industry",
        "Mumbai":    "Vehicles + construction + sea salt",
        "Kolkata":   "Vehicles + industry + coal",
        "Lucknow":   "Vehicles + construction dust",
        "Patna":     "Vehicles + crop burning",
    }
    return sources.get(city, "Vehicles + industrial emissions")

def health_risk(aqi):
    if aqi > 400: return "SEVERE — all outdoor activity dangerous"
    if aqi > 300: return "VERY HIGH — avoid outdoor exposure"
    if aqi > 200: return "HIGH — sensitive groups at risk"
    return "MODERATE — reduce prolonged outdoor activity"

def sensitive(aqi):
    if aqi > 300: return "ALL people affected — especially children & elderly"
    return "Children, elderly, asthma & heart patients"

def action(aqi):
    if aqi > 400: return "Stay indoors. Run air purifier. Wear N95 mask."
    if aqi > 300: return "Limit outdoor time. Wear N95 mask."
    return "Wear mask. Avoid exercise outdoors."

def er_visits(aqi):
    if aqi > 400: return "HIGH spike expected"
    if aqi > 300: return "MODERATE increase expected"
    return "Minor increase"


def run():
    print("\n😷 Checking air quality...")
    if not OPENAQ_KEY or OPENAQ_KEY == "your_openaq_key_here":
        print("  ⚠️  Add OPENAQ_KEY to .env  →  explore.openaq.org")
        return []
    data   = [get_aqi(z) for z in ZONES]
    alerts = build_alerts(data)
    print(f"  → {len(alerts)} air quality alerts")
    return alerts


if __name__ == "__main__":
    for a in run():
        print(f"  {a['title']} | AQI {a['details']['AQI (India CPCB Scale)']}")
