"""
api/main.py  —  FastAPI backend
Start: uvicorn api.main:app --reload --port 8000
Docs:  http://localhost:8000/docs
"""
from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from datetime import datetime
import os, asyncio, json

import pipeline
from config import MAPBOX_TOKEN

app = FastAPI(title="EarthWatch India", version="1.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# WebSocket connections
from fastapi import WebSocket, WebSocketDisconnect
ws_clients = []


# ── Serve Frontend ──────────────────────────
@app.get("/", response_class=HTMLResponse)
async def dashboard():
    path = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
    with open(path) as f:
        html = f.read()
    # Inject the Mapbox token
    html = html.replace("__MAPBOX_TOKEN__", MAPBOX_TOKEN or "")
    return html


# ── Incidents API ───────────────────────────
@app.get("/api/incidents")
async def get_incidents():
    incidents = pipeline.get_incidents()
    return {
        "count":      len(incidents),
        "last_run":   pipeline.get_last_run(),
        "incidents":  incidents,
    }


@app.get("/api/incidents/{incident_id}")
async def get_incident(incident_id: str):
    for inc in pipeline.get_incidents():
        if inc.get("id") == incident_id:
            return inc
    return {"error": "Not found"}


@app.get("/api/stats")
async def get_stats():
    incidents = pipeline.get_incidents()
    by_type   = {}
    for inc in incidents:
        t = inc.get("type", "other")
        by_type[t] = by_type.get(t, 0) + 1

    return {
        "total":    len(incidents),
        "critical": sum(1 for i in incidents if i.get("severity", 0) >= 7),
        "by_type":  by_type,
        "last_run": pipeline.get_last_run(),
        "timestamp": datetime.utcnow().isoformat(),
    }


# ── Run Pipeline ────────────────────────────
@app.post("/api/run")
async def trigger_pipeline(background_tasks: BackgroundTasks):
    """Trigger data pipeline. Runs in background, returns immediately."""
    background_tasks.add_task(run_and_broadcast)
    return {"message": "Pipeline started", "status": "running"}


async def run_and_broadcast():
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, pipeline.run)
    # Notify all connected dashboards
    msg = json.dumps({"type": "refresh"})
    for ws in ws_clients[:]:
        try:
            await ws.send_text(msg)
        except:
            ws_clients.remove(ws)


# ── WebSocket ────────────────────────────────
@app.websocket("/ws")
async def websocket(ws: WebSocket):
    await ws.accept()
    ws_clients.append(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        if ws in ws_clients:
            ws_clients.remove(ws)


# ── Health Check ─────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "app": "EarthWatch India", "time": datetime.utcnow().isoformat()}


# ── Startup: run pipeline once on boot ───────
@app.on_event("startup")
async def startup():
    print("\n🚀 EarthWatch India starting up...")
    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, pipeline.run)
